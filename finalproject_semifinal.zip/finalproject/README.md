# Computer-Shop-management
Made an Inventory system for a computer hardware store. The project is developed using php, bootstrap, js ,sql.
Here are screenshots for the same.
1.Login Page
![Login Page](screenshots/Login.png "The Login Page")
2.Home Page and search bar
![Home Page](screenshots/HomePageUpper.png "The Upper view of homepage.")
3.Home Page bottom
![Home Page](screenshots/HomePageLower.png "The Home Page bottom")
4.Customer Cart
![Customer Cart Page](screenshots/Customercart.png "The Customer Cart Page")
5.Generate Bill
![Generate Bill](screenshots/Generatebill.png "The Generate Bill Page")