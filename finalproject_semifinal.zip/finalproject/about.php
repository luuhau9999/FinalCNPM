<?php
session_start();
include "mydbconnect.php";
$con=openDatabase();
$e= $_SESSION['e'];
$query="select * from users where email='$e'";
$row=useDatabase($query);
$result=$row->fetch_array();
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>About</title>
		<script src="js/jquery.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<link href="css/style.css" rel="stylesheet" type="text/css" media="all" >
		<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" >
	</head>
	
	<body>
		<!--<img src="ProfilePhoto/profile-background.png" style="opacity:0.7;" id="bg"/>-->
		<img src="ProfilePhoto/background4.jpg" style="opacity:0.7;" id="bg"/>
		<div class="col-md-8" style="margin-top:2%;">

			<div class="col-md-5" >
				<?php
				echo "<span class='abouta' >".$result['f_name']." ".$result['l_name']."</span>" ;
				$temp = $result['id'];
				echo "<br><br><img class='img-circle' height=250 width=200 src=ProfilePhoto/".$result['id']."/1.jpg/>";
				//echo "<br><br><img class='img-circle' height=250 width=200 src=ProfilePhoto/".$e;
				?>
				<br>
				<br>
				<span style="color:darkslategrey; font-size:33px; font-weight:bold;">&#10149 Goto Shop :</span>
				<br>

				<!--<a href="home.php" style="font-size:25px; font-weight:bold; text-decoration:none;  margin-left:4%; color:black;">  &#10162 Home page</a> -->
				<form action="home.php" >
					<button type="submit", class="about_gotoshop_btn" ><span>  &#10162 Home page</span></button>
				</form>
				<br>
				<!--<a href="profits.php" style="font-size:25px; font-weight:bold; text-decoration:none;  margin-left:4%; color:black;">  &#10162 Profit page</a> -->
				<form action="profits.php" >
					<button type="submit", class="about_gotoshop_btn" ><span>  &#10162 Profit page</span></button>
				</form>
				<br>
				<!--<a href="logout.php "style="font-size:25px; font-weight:bold; text-decoration:none; margin-left:4%; color:black;"> &#10162 Logout</a>-->
				<form action="logout.php" >
					<button type="submit", class="about_gotoshop_btn" ><span>  &#10162 Logout</span></button>
				</form>
			</div>
			<div class="col-md-6 ">
				<br>
				<!--
				<div class="about_dong_gt">
				<h3 style="color:black", style="font-weight: bold";>CNH Computer Shop "Thỏa đam mê, Phê khách hàng"</h3>
				</div> -->
				<br>
				<span class="Newabout" >Email</span>

				<div class="input-group">
					<span class="input-group-addon" style="border-radius:0; font-size:20px;"/>&#9993</span>
					<span class="input-group-addon" style="border-radius:0; background-color:pink;font-family:serif; font-size:22px;"/><?php echo $result['email']; ?></span>
				</div>
				<br>
				<span class="Newabout" >Phone Number</span>

				<div class="input-group">
					<span class="input-group-addon " style="border-radius:0; font-size:20px; margin-right:2%;"/>&#9990</span>
					<span class="input-group-addon" style="border-radius:0; background-color:pink;font-family:serif; font-size:22px;"/><?php echo $result['phone_number']; ?></span>
					<!--
					<span class="input-group-addon " style="border-radius:0; background-color:lightgray"/></span>
					<span class="input-group-addon " style="border-radius:0;background-color:lightgray;"/></span>
					<span class="input-group-addon " style="border-radius:0;background-color:lightgray;"/></span> -->
				</div>
				<br>
				<span class="Newabout" >Address</span>

				<div class="input-group">
					<span class="input-group-addon" style="border-radius:0; font-size:20px;"/>&#10162</span>
					<span class="input-group-addon" style="border-radius:0; background-color:pink;font-family:serif; font-size:22px;"/><?php echo $result['address']; ?></span>
				</div>
				<br>
				
				
				<!-- <span style="font-style:italic; font-size:20px"> <a href="change_password\change_password.php" class="col-md-12 col-md-offset-3" style="text-decoration:none; color:red;font-weight:bold;">Change Your Password here!</a></span> */
				<br> -->
				<br>
				<form action="change_password.php" >
					<button type="submit", class="about_changepass_btn" >Change Your Password </button>
				</form>
			</div>
		</div>
	</body>
</html>
