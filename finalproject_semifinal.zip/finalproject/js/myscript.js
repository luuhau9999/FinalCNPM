function myFunction() {
    window.print();
}
